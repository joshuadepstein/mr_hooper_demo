const http = require('http');
const fs = require('fs');
const path = require('path');

// In-memory state for players and connected clients.
const players = {};
let nextId = 1;
const clients = []; // Array of { res, playerId }
// Track active balls (shots) in the world
const balls = [];
let nextBallId = 1;
// Keep track of game scores for left and right hoops
const scores = { left: 0, right: 0 };

// Helper to send a Server-Sent Event to a client response.
function sendEvent(res, data) {
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

// Broadcast an event to all connected clients.
function broadcast(data) {
  clients.forEach(client => sendEvent(client.res, data));
}

// Create HTTP server handling static files, SSE connections, and move commands.
const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;

  if (pathname === '/connect' && req.method === 'GET') {
    // Assign a new player ID and random starting position.
    const id = nextId++;
    const player = {
      id,
      x: Math.random() * 600 + 50,
      y: Math.random() * 400 + 50
    };
    players[id] = player;
    // Configure SSE response headers.
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    // Send initialization event to this client with assigned ID, existing players and current scores.
    sendEvent(res, { type: 'init', id, players: Object.values(players), scores });
    // Notify all other clients about this new player.
    broadcast({ type: 'add', player });
    // Track this client's SSE response.
    const clientInfo = { res, playerId: id };
    clients.push(clientInfo);
    // Clean up on client disconnect.
    req.on('close', () => {
      const index = clients.indexOf(clientInfo);
      if (index !== -1) clients.splice(index, 1);
      delete players[id];
      broadcast({ type: 'remove', id });
    });
  } else if (pathname === '/move' && req.method === 'POST') {
    // Process a movement command for a player.
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const player = players[data.id];
        if (player) {
          const speed = 5;
          switch (data.dir) {
            case 'left':
              player.x -= speed;
              break;
            case 'right':
              player.x += speed;
              break;
            case 'up':
              player.y -= speed;
              break;
            case 'down':
              player.y += speed;
              break;
          }
          // Broadcast updated position.
          broadcast({ type: 'update', id: player.id, x: player.x, y: player.y });
        }
      } catch (e) {
        // ignore malformed data
      }
      res.writeHead(200);
      res.end();
    });
  } else if (pathname === '/shoot' && req.method === 'POST') {
    // Handle shooting a ball
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const player = players[data.id];
        if (player) {
          const dir = data.dir;
          // Determine velocity based on direction
          let vx = 0, vy = 0;
          const speed = 8;
          switch (dir) {
            case 'left':
              vx = -speed; break;
            case 'right':
              vx = speed; break;
            case 'up':
              vy = -speed; break;
            case 'down':
              vy = speed; break;
            default:
              // if no direction, default to right
              vx = speed;
          }
          const ball = {
            id: nextBallId++,
            x: player.x,
            y: player.y,
            vx,
            vy,
            ownerId: data.id
          };
          balls.push(ball);
          // Inform clients about new ball
          broadcast({ type: 'addBall', ball: { id: ball.id, x: ball.x, y: ball.y } });
        }
      } catch (e) {
        // ignore
      }
      res.writeHead(200);
      res.end();
    });
  } else {
    // Serve static files from the 'public' directory. Default to index.html.
    let filePath = path.join(__dirname, 'public', pathname === '/' ? 'index.html' : pathname);
    // Prevent directory traversal vulnerability.
    const resolvedPath = path.resolve(filePath);
    const rootDir = path.resolve(path.join(__dirname, 'public'));
    if (!resolvedPath.startsWith(rootDir)) {
      res.writeHead(403);
      return res.end('Forbidden');
    }
    fs.readFile(resolvedPath, (err, content) => {
      if (err) {
        res.writeHead(404);
        res.end('Not found');
      } else {
        // Basic content type mapping.
        const ext = path.extname(resolvedPath).toLowerCase();
        const mimeTypes = {
          '.html': 'text/html',
          '.css': 'text/css',
          '.js': 'application/javascript',
          '.png': 'image/png',
          '.jpg': 'image/jpeg',
          '.jpeg': 'image/jpeg'
        };
        res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
        res.end(content);
      }
    });
  }
});

// Periodically update ball positions and broadcast changes.
function updateBalls() {
  const removeIds = [];
  balls.forEach(ball => {
    ball.x += ball.vx;
    ball.y += ball.vy;
    // check out of bounds
    if (ball.x < 0 || ball.x > 800 || ball.y < 0 || ball.y > 500) {
      removeIds.push(ball.id);
      return;
    }
    // Check scoring against simple hoop regions
    // Left hoop: small region near left edge
    if (ball.x < 50 && ball.y > 200 && ball.y < 300) {
      // Increment score for the right side (shooting into left hoop)
      scores.left++;
      broadcast({ type: 'score', playerId: ball.ownerId, side: 'left', scores });
      removeIds.push(ball.id);
      return;
    }
    // Right hoop: near right edge
    if (ball.x > 750 && ball.y > 200 && ball.y < 300) {
      scores.right++;
      broadcast({ type: 'score', playerId: ball.ownerId, side: 'right', scores });
      removeIds.push(ball.id);
      return;
    }
    // Broadcast updated ball position
    broadcast({ type: 'updateBall', id: ball.id, x: ball.x, y: ball.y });
  });
  // Remove balls that scored or left bounds
  if (removeIds.length > 0) {
    for (const id of removeIds) {
      const index = balls.findIndex(b => b.id === id);
      if (index !== -1) balls.splice(index, 1);
      broadcast({ type: 'removeBall', id });
    }
  }
}
// Start update loop at ~20 ticks per second
setInterval(updateBalls, 50);

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
  console.log(`SSE server listening on port ${PORT}`);
});