const http = require('http');
const fs = require('fs');
const path = require('path');

// In-memory state for players and connected clients.
const players = {};
let nextId = 1;
const clients = []; // Array of { res, playerId }

// Helper to send a Server-Sent Event to a client response.
function sendEvent(res, data) {
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

// Broadcast an event to all connected clients.
function broadcast(data) {
  clients.forEach(client => sendEvent(client.res, data));
}

// Create HTTP server handling static files, SSE connections, and move commands.
const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;

  if (pathname === '/connect' && req.method === 'GET') {
    // Assign a new player ID and random starting position.
    const id = nextId++;
    const player = {
      id,
      x: Math.random() * 600 + 50,
      y: Math.random() * 400 + 50
    };
    players[id] = player;
    // Configure SSE response headers.
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    // Send initialization event to this client with assigned ID and existing players.
    sendEvent(res, { type: 'init', id, players: Object.values(players) });
    // Notify all other clients about this new player.
    broadcast({ type: 'add', player });
    // Track this client's SSE response.
    const clientInfo = { res, playerId: id };
    clients.push(clientInfo);
    // Clean up on client disconnect.
    req.on('close', () => {
      const index = clients.indexOf(clientInfo);
      if (index !== -1) clients.splice(index, 1);
      delete players[id];
      broadcast({ type: 'remove', id });
    });
  } else if (pathname === '/move' && req.method === 'POST') {
    // Process a movement command for a player.
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const player = players[data.id];
        if (player) {
          const speed = 5;
          switch (data.dir) {
            case 'left':
              player.x -= speed;
              break;
            case 'right':
              player.x += speed;
              break;
            case 'up':
              player.y -= speed;
              break;
            case 'down':
              player.y += speed;
              break;
          }
          // Broadcast updated position.
          broadcast({ type: 'update', id: player.id, x: player.x, y: player.y });
        }
      } catch (e) {
        // ignore malformed data
      }
      res.writeHead(200);
      res.end();
    });
  } else {
    // Serve static files from the 'public' directory. Default to index.html.
    let filePath = path.join(__dirname, 'public', pathname === '/' ? 'index.html' : pathname);
    // Prevent directory traversal vulnerability.
    const resolvedPath = path.resolve(filePath);
    const rootDir = path.resolve(path.join(__dirname, 'public'));
    if (!resolvedPath.startsWith(rootDir)) {
      res.writeHead(403);
      return res.end('Forbidden');
    }
    fs.readFile(resolvedPath, (err, content) => {
      if (err) {
        res.writeHead(404);
        res.end('Not found');
      } else {
        // Basic content type mapping.
        const ext = path.extname(resolvedPath).toLowerCase();
        const mimeTypes = {
          '.html': 'text/html',
          '.css': 'text/css',
          '.js': 'application/javascript',
          '.png': 'image/png',
          '.jpg': 'image/jpeg',
          '.jpeg': 'image/jpeg'
        };
        res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
        res.end(content);
      }
    });
  }
});

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
  console.log(`SSE server listening on port ${PORT}`);
});